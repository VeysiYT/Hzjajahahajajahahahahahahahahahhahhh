package com.forsekany.breakable_bedrock;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BreakableBedrock implements ModInitializer {
    public static final String MOD_ID = "breakable_bedrock";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Breakable Bedrock mod loaded!");
    }
}
