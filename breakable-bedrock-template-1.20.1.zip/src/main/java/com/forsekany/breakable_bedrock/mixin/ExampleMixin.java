package com.forsekany.breakable_bedrock.mixin;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractBlock.class)
public class AbstractBlockMixin {

    @Inject(method = "getHardness", at = @At("HEAD"), cancellable = true)
    private void makeBedrockBreakable(BlockState state, CallbackInfoReturnable<Float> cir) {
        if (state.isOf(Blocks.BEDROCK)) {
            // Setting hardness to 1.5f makes it take ~1 second to break with a pickaxe
            cir.setReturnValue(1.5f);
        }
    }
}
